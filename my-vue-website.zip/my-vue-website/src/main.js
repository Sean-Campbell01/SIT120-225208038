import { createApp } from 'vue'
import './assets/styles/styles.css'
import App from './App.vue'

import AppHeader from './components/AppHeader.vue'
import AppFooter from './components/AppFooter.vue'

const app = createApp(App)
app.component('AppHeader', AppHeader)
app.component('AppFooter', AppFooter)
app.mount('#app')
