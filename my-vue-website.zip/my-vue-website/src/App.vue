<template>
  <div id="app-layout">
    <AppHeader :currentView="currentView" @navigate="setView" />

    <main>
      <HomeView v-if="currentView === 'home'" @navigate="setView" />
      <AboutView v-else-if="currentView === 'about'" />
      <DonationView v-else-if="currentView === 'donation'" />
    </main>

    <AppFooter @navigate="setView" />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import AppHeader from './components/AppHeader.vue'
import AppFooter from './components/AppFooter.vue'
import HomeView from './components/HomeView.vue'
import AboutView from './components/AboutView.vue'
import DonationView from './components/DonationView.vue'

const currentView = ref('home')

function setView(view) {
  currentView.value = view
  // Footer links are at the bottom of the page, so return to the top on each change
  window.scrollTo(0, 0)
}
</script>