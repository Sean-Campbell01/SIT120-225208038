<template>
  <div id="app-layout">
    <AppHeader :currentView="currentView" @navigate="setView" />

    <main>
      <HomeView v-if="currentView === 'home'" />
      <AboutView v-if="currentView === 'about'" />
      <ServicesView v-if="currentView === 'services'" />

    </main>

    <AppFooter />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import HomeView from './components/HomeView.vue'
import AboutView from './components/AboutView.vue'
import ServicesView from './components/ServicesView.vue'

const currentView = ref('home')

function setView(view) {
  currentView.value = view
}
</script>

<style>
#app-layout {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}
</style>