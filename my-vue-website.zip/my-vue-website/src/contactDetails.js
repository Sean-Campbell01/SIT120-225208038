export default {
    email: 'rhinohelp@domain.org.com',

    phone: '+61 11111111',

    instagram: 'org.rhinohelp',
    x: 'org.rhinohelp'
}