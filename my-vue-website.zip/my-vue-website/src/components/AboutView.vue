<template>
  <section>
    <h2>Meet Our Team</h2>
    <p class="center">
      Save Our Rhinos began as a result of one family safari and a basic question: What will happen to the rhino's if no one takes action. Today, our small but efficient group organises expeditions, holds community discussions, and collects donations that is used in the protection of rhinos endangered by poaching. All people listed here are essential to our operations, and we all need your help.
    </p>

    <article v-for="member in team" :key="member.role" class="team-member">
      <img :src="member.img" :alt="member.alt">
      <div>
        <h3>{{ member.name }} - {{ member.role }}</h3>
        <p>{{ member.bio }}</p>
      </div>
    </article>
  </section>
</template>

<script setup>
import member1Img from '../assets/images/member1.jpg'
import member2Img from '../assets/images/member2.jpg'
import member3Img from '../assets/images/member3.jpg'


const team = [
  {
    name: 'Alex Morgan',
    role: 'CEO',
    alt: 'Photo of CEO Alex Morgan.',
    img: member1Img,
    bio: 'Alex Morgan, our founder and chief executive officer, first became passionate about rhino conservation following a family safari when he was still young. This instilled in him a deep desire to conserve rhinos and their habitat. His passion kept growing through the years until finally, the idea of Save Our Rhinos came to life. They currently run this organisation.'
  },
  {
    name: 'Sam Williams',
    role: 'Field Work Coordinator Sam Williams',
    alt: 'Photo of the Field Work Coordinator.',
    img: member2Img,
    bio: 'Sam Williams is our Field Operations Coordinator and oversees all missions conducted. This includes overseeing a number of missions simultaneously and ensuring that every mission is well resourced. They are crucial to the success of our missions due to their ability to organise and deal with challenges. Their contribution to our efforts ensures that we remain relevant in the field.'
  },
  {
    name: 'Jamie Wilson',
    role: 'Data Analyst',
    alt: 'Photo of data analyst Jamie Wilson',
    img: member3Img,
    bio: 'Our Data Analyst, Jamie Wilson, has been an integral part of our organisation for the last seven years. Using his love for data and the environment, he helps us comprehend the effects of our actions. His analyses have enabled our organisation to make smarter choices and find ways to enhance our programs. Due to Jamie’s skills, Save Our Rhinos can create a greater impact for our horned friends.'
  }
]
</script>