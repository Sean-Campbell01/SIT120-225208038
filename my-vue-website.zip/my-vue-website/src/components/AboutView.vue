<template>
  <section>
    <h2>Meet Our Team</h2>

    <div class="team-member">
      <img :src="member1Img" alt="Photo of CEO.">
      <div>
        <h3>Team member 1 - CEO</h3>
        <p>Team member 1 is the CEO and founder of Save Our Rhinos. After a family safari trip as a child their passion was ignited, and has led them to starting this organisation.</p>
      </div>
    </div>

    <div class="team-member">
      <img :src="member2Img" alt="Photo of Field Work Coordinator.">
      <div>
        <h3>Team member 2 - Field Work Coordinator</h3>
        <p>Team member 2 is the Coordinator for all active field work missions. They often are managing multiple missions at once and are crucial to our operation.</p>
      </div>
    </div>

    <div class="team-member">
      <img :src="member3Img" alt="Photo of CFO.">
      <div>
        <h3>Team member 3 - CFO</h3>
        <p>Team member 3 is our CFO. They have been with the organisation for 7 years now and have used their passion and expertise to allow us to create further impact than ever before.</p>
      </div>
    </div>
  </section>
</template>

<script setup>
import member1Img from '../assets/images/member1.jpg'
import member2Img from '../assets/images/member2.jpg'
import member3Img from '../assets/images/member3.jpg'
</script>