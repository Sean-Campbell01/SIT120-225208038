<template>
  <section>
    <h1>Thank You For Choosing to Donate!</h1>
    <h2>Choose Payment Option Below</h2>
    <div class="two_columns">
      <section>
        <h3>Paypal</h3>
        <button>Pay</button>
      </section>
      <section>
        <h3>Credit Card</h3>
        <button>Pay</button>
      </section>
    </div>
  </section>
</template>

<script setup>
</script>