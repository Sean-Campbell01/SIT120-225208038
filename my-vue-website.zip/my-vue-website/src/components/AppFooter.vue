<template>
  <footer>
    <p>Copyright &copy; 2026 Rhino Help ORG.</p>
    <p>Please read our Privacy Policy</p>
  </footer>
</template>

<script setup>
</script>