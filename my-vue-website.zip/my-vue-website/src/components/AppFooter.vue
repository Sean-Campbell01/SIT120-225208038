<template>
  <footer class="site-footer">
    <div class="footer-grid">
      <div class="footer-block">
        <h2 class="footer-heading">Contact Us</h2>
        <ul class="footer-list">
          <li>Email: <a :href="'mailto:' + contact.email">{{ contact.email }}</a></li>
          <li>Phone: <a :href="'tel:' + contact.phone.replace(/\s/g, '')">{{ contact.phone }}</a></li>
          <li>Instagram: {{ contact.instagram }}</li>
          <li>X: {{ contact.x }}</li>
        </ul>
      </div>

      <nav class="footer-block" aria-label="Footer">
        <h2 class="footer-heading">Quick Links</h2>
        <ul class="footer-list">
          <li v-for="link in links" :key="link.view">
            <button type="button" class="footer-link" @click="$emit('navigate', link.view)">
              {{ link.label }}
            </button>
          </li>
        </ul>
      </nav>
    </div>

    <p class="copyright">Copyright &copy; {{ year }} Save Our Rhinos.</p>
  </footer>
</template>

<script setup>
import contact from '../contactDetails.js'

defineEmits(['navigate'])

const year = new Date().getFullYear()

const links = [
  { view: 'home', label: 'Home' },
  { view: 'about', label: 'Our Team' },
  { view: 'services', label: 'Donate' }
]
</script>