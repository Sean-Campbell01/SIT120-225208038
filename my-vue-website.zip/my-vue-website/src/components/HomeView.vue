<template>
  <section>
    <h2>The rhino's need your help</h2>
    <div class="hero">
      <img :src="rhinoImg" alt="Photo of a rhino.">
      <button>Donate</button>
    </div>
  </section>

  <div class="two_columns">
    <section>
      <h3>Learn how you can get involved!</h3>
      <p>Come to one of our seminars in your area to learn how you can get involved. We need assistance in multiple areas. Email us to find out more!</p>

      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Role</th>
              <th>Time Commitment</th>
              <th>Location</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Field Volunteer</td>
              <td>4 hrs/week</td>
              <td>Reserve site</td>
            </tr>
            <tr>
              <td>Community Educator</td>
              <td>3 hrs/Month</td>
              <td>Local schools to you</td>
            </tr>
            <tr>
              <td>Fundraising Coordinator</td>
              <td>2 hrs/week</td>
              <td>Home and local events</td>
            </tr>
            <tr>
              <td>Events Volunteer</td>
              <td>5 hrs/Month</td>
              <td>Local events</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <section>
      <h3>Contact Us</h3>
      <ul>
        <li>Email: rhinohelp.org.com</li>
        <li>Phone: +61 11111111</li>
        <li>Instagram: org.rhinohelp</li>
        <li>X: org.rhinohelp</li>
      </ul>
    </section>
  </div>
  <div>
    <ContactForm formTitle="Contact Us" @submit-form="handleFormSubmit" />

    <div v-if="submittedDetails" class="acknowledgement-card">
      <h3>Thank you for reaching out!</h3>
      <p>We've received your message and will get back to you shortly.</p>
      <ul>
        <li><strong>Name:</strong> {{ submittedDetails.name }}</li>
        <li><strong>Email:</strong> {{ submittedDetails.email }}</li>
        <li><strong>Phone:</strong> {{ submittedDetails.phone }}</li>
        <li><strong>Subject:</strong> {{ submittedDetails.subject }}</li>
        <li><strong>Volunteer Hours Offered:</strong> {{ submittedDetails.hours }}</li>
        <li><strong>Preferred Contact Method:</strong> {{ submittedDetails.contactMethod }}</li>
      </ul>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import ContactForm from './ContactForm.vue'
import rhinoImg from '../assets/images/rhinophoto.jpg'

const submittedDetails = ref(null)

function handleFormSubmit(payload) {
  submittedDetails.value = payload
}
</script>