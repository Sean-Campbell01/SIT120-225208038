<template>
  <section>
    <h2>The rhinos need your help</h2>
    <div class="hero">
      <img :src="rhinoImg" alt="Photo of a rhino.">
      <button type="button" class="cta" @click="$emit('navigate', 'donation')">Donate</button>
    </div>
  </section>


  <div class="two-columns">
    <section>
      <h3>Learn how you can get involved!</h3>
      <p>Come to one of our seminars in your area to learn how you can get involved. We need assistance in multiple areas. Email us to find out more!</p>

      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>Role</th>
              <th>Time Commitment</th>
              <th>Location</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="role in volunteerRoles" :key="role.name">
              <td>{{ role.name }}</td>
              <td>{{ role.time }}</td>
              <td>{{ role.location }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <section>
      <h3>Contact Us</h3>
      <ul>
        <li>Email: {{ contact.email }}</li>
        <li>Phone: {{ contact.phone }}</li>
        <li>Instagram: {{ contact.instagram }}</li>
        <li>X: {{ contact.x }}</li>
      </ul>
    </section>
  </div>

  <div>
    <ContactForm formTitle="Send Us a Message" @submit-form="handleFormSubmit" />

    <div v-if="submittedDetails" class="acknowledgement-card">
      <h3>Thank you for reaching out!</h3>
      <p>We've received your message and will get back to you shortly.</p>
      <ul>
        <li><strong>Name:</strong> {{ submittedDetails.name }}</li>
        <li><strong>Email:</strong> {{ submittedDetails.email }}</li>
        <li><strong>Phone:</strong> {{ submittedDetails.phone }}</li>
        <li><strong>Subject:</strong> {{ submittedDetails.subject }}</li>
        <li><strong>Volunteer Hours Offered:</strong> {{ submittedDetails.hours }}</li>
        <li><strong>Preferred Contact Method:</strong> {{ submittedDetails.contactMethod }}</li>
      </ul>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import ContactForm from './ContactForm.vue'
import rhinoImg from '../assets/images/rhinophoto.jpg'
import contact from '../contactDetails.js'

defineEmits(['navigate'])

const volunteerRoles = [
  { name: 'Field Volunteer', time: '4 hrs/week', location: 'Reserve site' },
  { name: 'Community Educator', time: '3 hrs/month', location: 'Local schools to you' },
  { name: 'Fundraising Coordinator', time: '2 hrs/week', location: 'Home and local events' },
  { name: 'Events Volunteer', time: '5 hrs/month', location: 'Local events' }
]

const submittedDetails = ref(null)

function handleFormSubmit(payload) {
  submittedDetails.value = payload
}
</script>  