<template>
  <section>
    <h2>Thank You For Choosing to Donate!</h2>
    <p>
      Every donation goes straight to protecting rhinos in the field. Your gift helps fund anti-poaching efforts, rhino rescue missions and vital veterinary medical services. Even a small amount makes a difference. Choose a payment option below to get started.
    </p>
    <p class="center">Choose Payment Option Below</p>

    <div class="two-columns">
      <section v-for="option in paymentOptions" :key="option">
        <h3>{{ option }}</h3>
        <button
          type="button"
          :aria-pressed="selectedMethod === option"
          @click="selectMethod(option)"
        >Pay</button>
      </section>
    </div>

    <DonationForm
      v-if="selectedMethod"
      :payment-method="selectedMethod"
      @submit-donation="showReceipt"
    />

    <div v-if="receipt" class="acknowledgement-card">
      <h3>Donation Receipt</h3>
      <p>Thank you for your donation!</p>
      <ul>
        <li><strong>Amount:</strong> ${{ receipt.amount.toFixed(2) }}</li>
        <li><strong>Payment method:</strong> {{ receipt.method }}</li>
      </ul>
    </div>
  </section>
</template>

<script setup>
import { ref } from 'vue'
import DonationForm from './Donationform.vue'

const paymentOptions = ['PayPal', 'Credit Card']

const selectedMethod = ref('')
const receipt = ref(null)

function selectMethod(method) {
  selectedMethod.value = method
}

function showReceipt(donation) {
  receipt.value = donation
}
</script>