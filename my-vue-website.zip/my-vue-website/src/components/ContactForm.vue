<template>
  <section class="center">
    <h2>{{ formTitle }}</h2>
    <p>Please fill out this form and we will get back to you promptly!</p>
  </section>

  <!-- novalidate turns off the browser's own pop-up messages so the v-if messages below are used -->
  <form class="contact-form" novalidate @submit.prevent="submitForm">
    <div class="form-field">
      <label for="name">Name</label>
      <input type="text" id="name" v-model="form.name">
      <p v-if="errors.name" class="error-message">{{ errors.name }}</p>
    </div>

    <div class="form-field">
      <label for="email">Email</label>
      <input type="email" id="email" v-model="form.email">
      <p v-if="errors.email" class="error-message">{{ errors.email }}</p>
    </div>

    <div class="form-field">
      <label for="phone">Phone Number</label>
      <input type="tel" id="phone" inputmode="numeric" placeholder="10 digits" maxlength="10" v-model="form.phone">
      <p v-if="errors.phone" class="error-message">{{ errors.phone }}</p>
    </div>

    <div class="form-field">
      <label for="subject">Subject</label>
      <select id="subject" v-model="form.subject">
        <option value="">Select a subject</option>
        <option v-for="option in subjectOptions" :key="option" :value="option">{{ option }}</option>
      </select>
      <p v-if="errors.subject" class="error-message">{{ errors.subject }}</p>
    </div>

    <div class="form-field">
      <label for="hours">How many volunteer hours can you offer per month?</label>
      <input type="number" id="hours" min="0" v-model.number="form.hours">
      <p v-if="errors.hours" class="error-message">{{ errors.hours }}</p>
    </div>

    <fieldset class="form-field">
      <legend>Preferred Contact Method</legend>
      <div class="radio-group">
        <label><input type="radio" value="Email" v-model="form.contactMethod"> Email</label>
        <label><input type="radio" value="Phone" v-model="form.contactMethod"> Phone</label>
      </div>
      <p v-if="errors.contactMethod" class="error-message">{{ errors.contactMethod }}</p>
    </fieldset>

    <div class="form-field full-width">
      <label for="message">Message</label>
      <textarea id="message" placeholder="Write your message here." v-model="form.message"></textarea>
      <p v-if="errors.message" class="error-message">{{ errors.message }}</p>
    </div>

    <div class="form-field checkbox-field full-width">
      <input type="checkbox" id="newsletter" v-model="form.newsletter">
      <label for="newsletter">Subscribe to our newsletter</label>
    </div>

    <div class="form-field full-width">
      <button type="submit">Submit</button>
    </div>

    <p v-if="showSuccess" class="success-message full-width">Thank you! Your message has been sent.</p>
  </form>
</template>

<script setup>
import { ref, reactive } from 'vue'

defineProps({
  formTitle: {
    type: String,
    default: 'Contact Form'
  }
})

const emit = defineEmits(['submit-form'])

const subjectOptions = ['Volunteering', 'Donations', 'Missions', 'Other']

const initialForm = {
  name: '',
  email: '',
  phone: '',
  subject: '',
  hours: null,
  contactMethod: '',
  message: '',
  newsletter: false
}

const form = ref({ ...initialForm })
const showSuccess = ref(false)


const errors = reactive({
  name: '',
  email: '',
  phone: '',
  subject: '',
  hours: '',
  contactMethod: '',
  message: ''
})

function validate() {
  const f = form.value

  errors.name = f.name.trim() === '' ? 'Please enter your name.' : ''

  if (f.email.trim() === '') {
    errors.email = 'Please enter your email.'
  } else if (!/^\S+@\S+\.\S+$/.test(f.email.trim())) {
    errors.email = 'Please enter a valid email address.'
  } else {
    errors.email = ''
  }

  if (f.phone.trim() === '') {
    errors.phone = 'Please enter your phone number.'
  } else if (!/^\d{10}$/.test(f.phone.trim())) {
    errors.phone = 'Phone number must be exactly 10 digits.'
  } else {
    errors.phone = ''
  }

  errors.subject = f.subject === '' ? 'Please select a subject.' : ''

  if (f.hours === null || f.hours === '') {
    errors.hours = 'Please enter a number of hours.'
  } else if (!Number.isFinite(f.hours) || f.hours < 0) {
    errors.hours = 'Hours must be 0 or more.'
  } else {
    errors.hours = ''
  }

  errors.contactMethod = f.contactMethod === '' ? 'Please select a contact method.' : ''
  errors.message = f.message.trim() === '' ? 'Please enter a message.' : ''

  return Object.values(errors).every(message => message === '')
}

function submitForm() {
  if (!validate()) {
    return
  }

  emit('submit-form', { ...form.value })
  showSuccess.value = true

  setTimeout(() => {
    form.value = { ...initialForm }
    showSuccess.value = false
  }, 2000)
}
</script>