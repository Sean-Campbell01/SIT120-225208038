<template>
  <section class="center">
    <h2>{{ formTitle }}</h2>
    <p>Please fill out this form and we will get back to you promptly!</p>
  </section>

  <form @submit.prevent="submitForm">
    <fieldset>
      <label for="name">Name</label>
      <input type="text" id="name" v-model="form.name">
      <p v-if="errors.name" class="error-message">Please enter your name.</p>
    </fieldset>

    <fieldset>
      <label for="email">Email</label>
      <input type="email" id="email" v-model="form.email">
      <p v-if="errors.email" class="error-message">Please enter your email.</p>
    </fieldset>

    <fieldset>
      <label for="phone">Phone Number</label>
      <input type="tel" id="phone" placeholder="10 digits" maxlength="10" v-model="form.phone">
      <p v-if="errors.phone" class="error-message">Please enter your phone number.</p>
    </fieldset>

    <fieldset>
      <label for="subject">Subject</label>
      <select id="subject" v-model="form.subject">
        <option value="">Select a subject</option>
        <option v-for="option in subjectOptions" :key="option" :value="option">{{ option }}</option>
      </select>
      <p v-if="errors.subject" class="error-message">Please select a subject.</p>
    </fieldset>

    <fieldset>
      <label for="hours">How many volunteer hours can you offer per month?</label>
      <input type="number" id="hours" min="0" v-model.number="form.hours">
      <p v-if="errors.hours" class="error-message">Please enter a number of hours.</p>
    </fieldset>

    <fieldset>
      <label>Preferred Contact Method</label>
      <div class="radio-group">
        <label><input type="radio" value="Email" v-model="form.contactMethod"> Email</label>
        <label><input type="radio" value="Phone" v-model="form.contactMethod"> Phone</label>
      </div>
      <p v-if="errors.contactMethod" class="error-message">Please select a contact method.</p>
    </fieldset>

    <fieldset>
      <label for="message">Message</label>
      <textarea id="message" placeholder="Write your message here." v-model="form.message"></textarea>
      <p v-if="errors.message" class="error-message">Please enter a message.</p>
    </fieldset>

    <fieldset class="checkbox-field">
      <input type="checkbox" id="newsletter" v-model="form.newsletter">
      <label for="newsletter">Subscribe to our newsletter</label>
    </fieldset>

    <fieldset>
      <button type="submit">Submit</button>
    </fieldset>

    <p v-if="showSuccess" class="error-message" style="color: #2f4f3f;">Thank you! Your message has been sent.</p>
  </form>
</template>

<script setup>
import { ref, reactive } from 'vue'

const props = defineProps({
  formTitle: {
    type: String,
    default: 'Contact Form'
  }
})

const emit = defineEmits(['submit-form'])

const subjectOptions = ['Volunteering', 'Donations', 'Missions', 'Other']

const initialForm = {
  name: '',
  email: '',
  phone: '',
  subject: '',
  hours: null,
  contactMethod: '',
  message: '',
  newsletter: false
}

const form = ref({ ...initialForm })
const showSuccess = ref(false)

const errors = reactive({
  name: false,
  email: false,
  phone: false,
  subject: false,
  hours: false,
  contactMethod: false,
  message: false
})

function validate() {
  errors.name = form.value.name === ''
  errors.email = form.value.email === ''
  errors.phone = form.value.phone === ''
  errors.subject = form.value.subject === ''
  errors.hours = form.value.hours === null || form.value.hours === ''
  errors.contactMethod = form.value.contactMethod === ''
  errors.message = form.value.message === ''

  return !Object.values(errors).some(hasError => hasError)
}

function submitForm() {
  if (!validate()) {
    return
  }

  emit('submit-form', { ...form.value })
  showSuccess.value = true

  setTimeout(() => {
    form.value = { ...initialForm }
    showSuccess.value = false
  }, 2000)
}
</script>