<template>
  <header class="site-header">
    <h1>
    <button type="button" class="brand" @click="$emit('navigate', 'home')">Save Our Rhinos</button>
    </h1>
  </header>

  <nav class="site-nav" aria-label="Main">
    <button
      v-for="link in links"
      :key="link.view"
      type="button"
      class="nav-link"
      :class="{ active: currentView === link.view }"
      :aria-current="currentView === link.view ? 'page' : null"
      @click="$emit('navigate', link.view)"
    >{{ link.label }}</button>
  </nav>
</template>

<script setup>
defineProps({
  currentView: {
    type: String,
    default: 'home'
  }
})

defineEmits(['navigate'])

const links = [
  { view: 'home', label: 'Home' },
  { view: 'about', label: 'Our Team' },
  { view: 'donation', label: 'Donate' }
]
</script>