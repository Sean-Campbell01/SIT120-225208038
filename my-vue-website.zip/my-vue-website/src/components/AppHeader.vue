<template>
  <header>
    <h1>Save Our Rhino's</h1>
  </header>
  <nav>
    <button
      class="nav-link"
      :class="{ active: currentView === 'home' }"
      @click="$emit('navigate', 'home')"
    >Home</button>
    <button
      class="nav-link"
      :class="{ active: currentView === 'about' }"
      @click="$emit('navigate', 'about')"
    >Our Team</button>
    <button
      class="nav-link"
      :class="{ active: currentView === 'services' }"
      @click="$emit('navigate', 'services')"
    >Donate</button>
  </nav>
</template>

<script setup>
defineProps({
  currentView: {
    type: String,
    default: 'home'
  }
})

defineEmits(['navigate'])
</script>