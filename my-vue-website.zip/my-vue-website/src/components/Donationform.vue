<template>
  <form class="donation-form" novalidate @submit.prevent="submitDonation">
    <h3>Donate with {{ paymentMethod }}</h3>

    <div class="form-field">
      <label for="amount">Donation amount ($)</label>
      <input
        type="number"
        id="amount"
        min="1"
        step="0.01"
        v-model.number="amount"
        @input="error = false"
      >
      <p v-if="error" class="error-message">Please enter an amount greater than 0.</p>
    </div>

    <div class="form-field">
      <button type="submit">Donate</button>
    </div>
  </form>
</template>

<script setup>
import { ref } from 'vue'

const props = defineProps({
  paymentMethod: {
    type: String,
    required: true
  }
})

const emit = defineEmits(['submit-donation'])

const amount = ref(null)
const error = ref(false)

function submitDonation() {
  if (!Number.isFinite(amount.value) || amount.value <= 0) {
    error.value = true
    return
  }

  emit('submit-donation', { amount: amount.value, method: props.paymentMethod })

  amount.value = null
  error.value = false
}
</script>